package com.insta.instaController;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.insta.instaDao.InstaDao;
import com.insta.instaDao.InstaDaoInterface;
import com.insta.instaEntity.InstaUser;

@RestController
@RequestMapping("api")
@CrossOrigin("*")
public class InstaController {
	
	@Autowired
	InstaDaoInterface id1=new InstaDao();
	
	@GetMapping("/instausers")
	
		public List<InstaUser> getAllUsers() throws Exception{
			//Sort sortByCreated = new Sort(Sort.Direction.DESC,"createdAt");
		List<InstaUser> l=id1.getAllUsers();	
		for(InstaUser iu:l) {
			System.out.println(iu.getName());
			System.out.println(iu.getId());
			System.out.println(iu.getPassword());
		}
		
			return l;
		}
	@PostMapping("/instausers")
	public InstaUser createInstaUser(@Valid @RequestBody InstaUser iu) throws Exception {
		
		InstaUser i=id1.createInstaUser(iu);
		System.out.println(i.getName());
		return i;
	}
	
	@DeleteMapping("/instausers/{id}")
	
	public void  deleteInstaUser(@	PathVariable("id") String id) throws Exception { ///change name here
		id1.deleteInstaUser(id);
	}
	
	@PutMapping("/instausers/{id}")
	public ResponseEntity<InstaUser> updateUser(@PathVariable("id") String id,@Valid @RequestBody InstaUser iu) throws Exception{
		
		iu.setId(id);
		InstaUser iu1=id1.updateInstaUser(iu);
		if(iu1==null) {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
		else {
			return new ResponseEntity<>(iu1,HttpStatus.OK);
		}
	}
	
	
	
	

}
