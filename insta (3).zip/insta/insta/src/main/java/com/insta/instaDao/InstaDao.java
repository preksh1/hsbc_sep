package com.insta.instaDao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.insta.instaEntity.InstaUser;
@Repository
public class InstaDao implements InstaDaoInterface {

	@Override
	public List<InstaUser> getAllUsers() throws Exception {
		// TODO Auto-generated method stub
		Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
		Connection con=DriverManager.getConnection("jdbc:derby:e:/db2");
		PreparedStatement ps=con.prepareStatement("select name,email,password from t1");
		ResultSet res=ps.executeQuery();
		//int i=0;
		InstaUser iu=null;
		List<InstaUser> ll=new ArrayList<InstaUser>();
		while(res.next()) {
			iu=new InstaUser();
			iu.setName(res.getString(1));
			iu.setId(res.getString(2));
			iu.setPassword(res.getString(3));
			ll.add(iu);
		}
		return ll;
	}

	@Override
	public InstaUser createInstaUser(InstaUser iu) throws Exception {
		// TODO Auto-generated method stub
		Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
		Connection con=DriverManager.getConnection("jdbc:derby:e:/db2");
		PreparedStatement ps=con.prepareStatement("insert into t1(name,email,password) values(?,?,?)");
		ps.setString(1, iu.getName());
		ps.setString(2, iu.getId());
		ps.setString(3, iu.getPassword());
		int i=ps.executeUpdate();
		InstaUser iu1=new InstaUser();
		if(i>0) {
			iu1.setName(iu.getName());
			iu1.setId(iu.getId());
			iu1.setPassword(iu.getPassword());
			return iu1;
		}
		else
			return null;
	}

	@Override
	public void deleteInstaUser(String id) throws Exception {
		Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
		Connection con=DriverManager.getConnection("jdbc:derby:e:/db2");
		PreparedStatement ps=con.prepareStatement("delete from t1 where email=?");
		ps.setString(1, id);
		int i=ps.executeUpdate();
		if(i>0) {
			System.out.println("deleted ");
		}
		else
			System.out.println("deletion not done");
		
	}

	@Override
	public InstaUser updateInstaUser(InstaUser iu) throws Exception {
		System.out.println("name and id are:"+iu.getName()+" "+iu.getId());
		Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
		Connection con=DriverManager.getConnection("jdbc:derby:e:/db2");
		PreparedStatement ps=con.prepareStatement("update t1 set name=?,password=? where email=?");
		System.out.println("in dao"+iu.getId()+iu.getName()+iu.getPassword());
		ps.setString(1, iu.getName());
		ps.setString(2, iu.getPassword());
		ps.setString(3, iu.getId());
		int i=ps.executeUpdate();
		if(i>0) {
			return iu;
		}
		else
			return null;
	}

	
}
