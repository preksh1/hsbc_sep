package com.insta.instaDao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.insta.instaEntity.InstaUser;
@Repository
public interface InstaDaoInterface {
	public List<InstaUser> getAllUsers() throws Exception;

	public InstaUser createInstaUser(InstaUser iu) throws Exception;

	public void deleteInstaUser(String name) throws Exception;

	public InstaUser updateInstaUser(InstaUser iu) throws Exception;

}
