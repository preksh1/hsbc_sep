import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppComponent } from './app.component';
import{HttpClientModule,HttpHeaders} from '@angular/common/http';
import { InstaComponent } from './insta/insta.component';
import {InstaserviceService } from './instaservice.service';
import { FormsModule } from '@angular/forms';
@NgModule({
  declarations: [
    AppComponent,
    InstaComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [InstaserviceService ],
  bootstrap: [AppComponent]
})
export class AppModule { }
