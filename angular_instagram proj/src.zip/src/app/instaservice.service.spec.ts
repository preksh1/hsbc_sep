import { TestBed } from '@angular/core/testing';

import { InstaserviceService } from './instaservice.service';

describe('InstaserviceService', () => {
  let service: InstaserviceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(InstaserviceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
