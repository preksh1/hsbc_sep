export class InstaUser{
    name:String;
    //createdAt:Date;
    id:String;
    password:String;
}