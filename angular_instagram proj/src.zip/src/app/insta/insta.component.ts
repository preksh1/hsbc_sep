import { Component,Input, OnInit } from '@angular/core';
import { InstaserviceService } from '../instaservice.service';
import { InstaUser } from '../InstaUser';
import {NgForm} from '@angular/forms';

@Component({
  selector: 'instaview',
  templateUrl: 'insta.component.html',
})
export class InstaComponent implements OnInit {

  instau:InstaUser[];
  newUser:InstaUser=new InstaUser();
  editing: boolean =false;
  editingUser:InstaUser= new InstaUser();

  constructor(
    private instaService:InstaserviceService,
    ) {}

  ngOnInit(): void {
    this.getUser();
  }
  getUser():void{
    console.log("hi");
    this.instaService.getUser().subscribe(instau=>this.instau =instau);
  }
  createInstaUser(instaform:NgForm):void{
    this.instaService.createInstaUser(this.newUser)
    .subscribe(createInstaUser=>{
      instaform.reset();
      this.newUser=new InstaUser();
      this.instau.unshift(createInstaUser)
    });
  }

  editUser(userData:InstaUser): void{
    this.editing =true;
    console.log(userData.name);
    Object.assign(this.editingUser,userData);
   // this.editingUser.id=userData.name;
    //console.log(this.editingUser.id+" "+userData.name);
  }
  
  deleteUser(id:string): void{
    console.log(id);

    this.instaService.deleteInstaUser(id).subscribe(()=>{
      this.instau=this.instau.filter(user=>user.id!=id);
    });

  }


  updateUser(userData:InstaUser):void{
    console.log(userData);
   // userData.id=this.editingUser.id;
    console.log(userData.id);
    this.instaService.updateUser(userData).subscribe(
      userUpdate=>{
        let existingUser =this.instau.find(user=>user.id === userUpdate.id);
        Object.assign(existingUser,userUpdate);
        this.clearEditing();
      });
  }

  clearEditing(): void{
    this.editingUser=new InstaUser();
    this.editing=false;
  }



/*
  createInstaUser(instaform: NgForm) :void {
    this.instaService.createInstaUser(this.newUser).then(this.newUser)
    .then(this.createInstaUser => {
      instaform.reset();
      this.newUser=new InstaUser();
      this.instaU.unshift(this.createInstaUser)
    });
  }
*/
}
