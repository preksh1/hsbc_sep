import { Injectable } from '@angular/core';
import {InstaUser} from './InstaUser';
import{HttpClient,HttpHeaders} from '@angular/common/http';

const httpOptions={
  headers:new HttpHeaders({'Content-Type':'application/json'})
};


@Injectable()
export class InstaserviceService {

  constructor( private http:HttpClient ) {}
  
  private baseUrl="http://localhost:7000";

  
  
  public getUser(){
      return this.http.get<InstaUser[]>(this.baseUrl+'/api/instausers/');
   }

   public createInstaUser(instaData: InstaUser){
     return this.http.post<InstaUser>(this.baseUrl+'/api/instausers/',instaData);

   }

   public deleteInstaUser(id:string){
     return this.http.delete<any>(this.baseUrl+'/api/instausers/'+id);
   }

   public updateUser(userData: InstaUser){

    return this.http.put<InstaUser>(this.baseUrl+'/api/instausers/'+userData.id,userData);
   
  }




}
